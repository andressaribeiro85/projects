import { Given, When, Then } from "cypress-cucumber-preprocessor/steps";
import HomePage from '../../../support/page-objects/home_page'
import SearchResultPage from '../../../support/page-objects/search_result'
import ProductAdd from '../../../support/page-objects/product_page_add_cart'
import CartPage from '../../../support/page-objects/cart_page'

let itemToSearch = 'Huggies Fralda Premium Natural Care M 32 Un'

Given("the user accessed the amazon home page", () => {
   cy.visit('/');
    //This wait command is the time necessary to insert the recaptcha .. when necessary
    cy.wait(3000)
});

When("the user search for a product seeing the results", () => {
      cy.on('uncaught:exception', (err, runnable) => {
    // Returning false prevents Cypress from failing the test
    return false;
     });
     cy.title().should('equal', 'Amazon.com.br | Tudo pra você, de A a Z.');
     HomePage.InsertSearch(itemToSearch);
     HomePage.SearchButtonClick();
 
     //Validating it is in list page product 
     cy.title().should('include', 'Amazon.com.br : ' + itemToSearch);
     cy.wait(7000);
 
     
});

When("click in the first option to this product", () => {
    //Clicking in the first product
     SearchResultPage.ResultClick();
    
     //Validating it is in product page
     cy.title().should('contain', 'Amazon.com.br');
});

When("insert this product in the cart", () => {
     ProductAdd.AddCart();
     ProductAdd.GoingToCart();
    
     //Validating it is in cart page
     cy.title().should('contain','Carrinho de compras da Amazon.com');
});

Then("the system should display the product price and the subtotal price", () => {
     cy.wait(5000);
     CartPage.comparePrice();
});
When("the user click in the remove button", () => {
    CartPage.RemoveButton();
    cy.wait(5000);
});
Then("the product is removed from the cart", () => {
    CartPage.elements.messageRemoved().invoke('text').should('contain', 'foi removido de Carrinho de compras.');
});
