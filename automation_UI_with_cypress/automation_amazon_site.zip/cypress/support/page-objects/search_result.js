class SearchResultPage {
    elements ={
        firstResult: () => cy.xpath('/html/body/div[1]/div[1]/div[1]/div[1]/div/span[1]/div[1]/div[3]/div/div/span/div/div/div[2]/div[1]/a/h2/span')
    }

    WaitElement(){
        cy.xpath('/html/body/div[1]/div[1]/div[1]/div[1]/div/span[1]/div[1]/div[3]/div/div/span/div/div/div[2]/div[1]/a/h2/span');
    }

    ResultClick(){
        this.elements.firstResult().click({ force:true });
    }

    
}

module.exports = new SearchResultPage();
require('cypress-xpath')

