class ProductAdd {
    elements ={
        addCart: () => cy.get('#add-to-cart-button'),
        goingCart: () => cy.xpath('//*[@id="sw-gtc"]/span/a')
    }

    AddCart(){
        this.elements.addCart().click({ force: true });
    }

    GoingToCart(){
        this.elements.goingCart().click(); 
    }
}

module.exports = new ProductAdd();
require('cypress-xpath')