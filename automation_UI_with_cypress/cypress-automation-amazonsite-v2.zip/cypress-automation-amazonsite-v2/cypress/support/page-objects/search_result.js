class SearchResultPage {
    elements ={
        addCart: () => cy.get('#a-autoid-1-announce'),
        cartId: () => cy.get('#nav-cart'),
        titlePageResult: () => cy.xpath('/html/body/div[1]/div[1]/span/div/h1/div/div[1]/div/div/div[2]/h2/span[3]')
    }

    titlePageResultText(item){
        this.elements.titlePageResult().invoke('text').should('contain', '"' + item +'"');
    }

    AddCartClick(){
        this.elements.addCart().click({ force:true });
    }

    CartClick() {
        this.elements.cartId().click({ force:true });
    }

    
}

module.exports = new SearchResultPage();
require('cypress-xpath')

