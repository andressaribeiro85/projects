class HomePage {
    elements ={
        inputSearch: () => cy.get('#twotabsearchtextbox'),
        buttonSearch: () => cy.get('#nav-search-submit-button')
    }

    InsertSearch(WordToSearch){
        this.elements.inputSearch().type(WordToSearch)
    }

    SearchButtonClick(){
        this.elements.buttonSearch().click();
    }
}

module.exports = new HomePage();