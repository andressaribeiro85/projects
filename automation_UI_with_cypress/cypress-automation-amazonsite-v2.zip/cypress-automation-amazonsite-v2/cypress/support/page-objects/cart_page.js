class CartPage {
    elements ={
        addItemButton: () => cy.xpath('/html/body/div[1]/div[1]/div[3]/div[5]/div/div[2]/div[1]/div/form/ul/div[3]/div[4]/div/div[2]/div[1]/span[1]/span[1]/fieldset/button[2]'),
        productPrice: () => cy.xpath('/html/body/div[1]/div[1]/div[3]/div[5]/div/div[2]/div[1]/div/form/ul/div[3]/div[4]/div/div[2]/ul/div[1]/div[1]/div/div/span/span/span[1]'),
        totalPrice: () => cy.xpath('/html/body/div[1]/div[1]/div[3]/div[5]/div/div[2]/div[1]/div/form/div[2]/div/span[2]/span'),
        qtd: () => cy.xpath('/html/body/div[1]/div[1]/div[3]/div[5]/div/div[2]/div[1]/div/form/ul/div[3]/div[4]/div/div[2]/div[1]/span[1]/span[1]/fieldset/div[2]/span[2]'),
        removeItemButton: () => cy.xpath('/html/body/div[1]/div[1]/div[3]/div[5]/div/div[2]/div[1]/div/form/ul/div[3]/div[4]/div/div[2]/div[1]/span[1]/span[1]/fieldset/button[1]'),
        messageRemoved: () => cy.xpath('/html/body/div[1]/div[1]/div[3]/div[5]/div/div[2]/div[1]/div/form/ul/div/div/div[1]/span')
       
    }

    takeOnlyNumber(text){
        const number = text.replace(/\D/ig, "");
        return parseFloat(number)
    }

    AddButton(){
        this.elements.addItemButton().click( {force: true })
    }

    compareQtd(n){
        this.elements.qtd().invoke('text').should('equal', n)
    }

    RemoveButton(){
        this.elements.removeItemButton().click({force: true })
    }

    comparePrice(){
        var priceUnit;
        this.elements.productPrice().should(($d) => {
            priceUnit = $d.text();
            });
     cy.wait(600);
     this.elements.totalPrice().should(($d) => {
        const total = $d.text();
        expect(total).equal(priceUnit);
      })
    }

    checkTotalPrice(){
        var total;
        this.elements.productPrice().then(($d) => {
        const pprice = $d.text();
        const priceTransformed = this.takeOnlyNumber(pprice);
        total = priceTransformed * 2;
        })
        this.elements.totalPrice().then(($d) => {
        const totalTotal = $d.text();
        const totalTransformed = this.takeOnlyNumber(totalTotal);
        expect(totalTransformed).equal(total);
      })
    }
}

module.exports = new CartPage();
require('cypress-xpath')