import { Given, When, Then } from "cypress-cucumber-preprocessor/steps";
import HomePage from '../../../support/page-objects/home_page'
import SearchResultPage from '../../../support/page-objects/search_result'
import CartPage from '../../../support/page-objects/cart_page'

let itemToSearch = 'fraldas huggies baby 32un'

Given("the user accessed the amazon home page", () => {
   cy.visit('/');
    //This wait command is the time necessary to insert the recaptcha .. when necessary
    cy.wait(6000);
});

When("the user search for a product seeing the results", () => {
    // Returning false prevents Cypress from failing the test
    cy.on('uncaught:exception', (err, runnable) => {
        return false;
    });
    cy.title().should('equal', 'Amazon.com.br | Tudo pra você, de A a Z.');
    HomePage.InsertSearch(itemToSearch);
    HomePage.SearchButtonClick();
    cy.title().should('include', 'Amazon.com.br : ' + itemToSearch);
       
});

When("clicks in the add button in the first option to this product", () => {
    //Clicking in the first product
    cy.wait(6000);
    SearchResultPage.AddCartClick();
});

When("clicks in the cart button on the top menu", () => {
     SearchResultPage.CartClick();
});

Then("the system should go to the cart page and display the product price and the subtotal price", () => {
    //Verify if it is the the cart page
    cy.url().should('include', '/gp/cart/view.html?ref_=nav_cart')
    cy.title().should('contain','Carrinho de compras da Amazon.com');

    //Assertion with quantid
    CartPage.compareQtd('1');

    //Assertion with price 
    CartPage.comparePrice();
});

When("the user click in the remove button", () => {
    CartPage.RemoveButton();
    cy.wait(5000);
});
Then("the product is removed from the cart", () => {
    CartPage.elements.messageRemoved().invoke('text').should('contain', 'foi removido de Carrinho de compras.');
});
