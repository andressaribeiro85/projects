import HomePage from '../support/page-objects/home_page'
import SearchResultPage from '../support/page-objects/search_result'
import ProductAdd from '../support/page-objects/product_page_add_cart'
import CartPage from '../support/page-objects/cart_page'

describe('Search to a product in the amazon site', () => {
  let itemToSearch = 'Huggies Fralda Premium Natural Care M 32 Un'

   beforeEach(() => {
    cy.visit('/');
    //This wait command is the time necessary to insert the recaptcha .. when necessary
    cy.wait(3000)
  });

  it('Search to a product and adding to a card', () => {
    cy.on('uncaught:exception', (err, runnable) => {
    // Returning false prevents Cypress from failing the test
    return false;
  });
    //Searching to the product
    cy.title().should('equal', 'Amazon.com.br | Tudo pra você, de A a Z.');
    HomePage.InsertSearch(itemToSearch);
    HomePage.SearchButtonClick();

    
    //Validating it is in list page product 
    cy.title().should('include', 'Amazon.com.br : ' + itemToSearch);
    cy.wait(7000);

    //Clicking in the first product
    SearchResultPage.ResultClick();
   
    //Validating it is in product page
    cy.title().should('contain', 'Amazon.com.br');
    ProductAdd.AddCart();
    ProductAdd.GoingToCart();

    //Validating it is in cart page
    cy.title().should('contain','Carrinho de compras da Amazon.com');

    cy.wait(5000);
    CartPage.comparePrice();
    
    
    CartPage.AddButton();
    cy.wait(5000);
    CartPage.compareQtd('2');


    
  })
})